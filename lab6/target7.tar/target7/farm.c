/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_407(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_453(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_397()
{
    return 2425393240U;
}

unsigned getval_129()
{
    return 3284633929U;
}

unsigned addval_398(unsigned x)
{
    return x + 3251079496U;
}

void setval_200(unsigned *p)
{
    *p = 2455284152U;
}

unsigned getval_445()
{
    return 3347662944U;
}

unsigned addval_113(unsigned x)
{
    return x + 2425641040U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_417(unsigned *p)
{
    *p = 3286272360U;
}

unsigned getval_478()
{
    return 2411974297U;
}

unsigned addval_216(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_376(unsigned x)
{
    return x + 3229929101U;
}

unsigned getval_111()
{
    return 3223376281U;
}

unsigned getval_104()
{
    return 3281047177U;
}

unsigned getval_117()
{
    return 3353381192U;
}

unsigned getval_315()
{
    return 3372797576U;
}

unsigned addval_155(unsigned x)
{
    return x + 3223896713U;
}

unsigned addval_432(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_330()
{
    return 3286272072U;
}

unsigned addval_152(unsigned x)
{
    return x + 3224945289U;
}

void setval_312(unsigned *p)
{
    *p = 3232023177U;
}

unsigned addval_480(unsigned x)
{
    return x + 3281047949U;
}

unsigned getval_427()
{
    return 2430634312U;
}

unsigned addval_218(unsigned x)
{
    return x + 3676361097U;
}

void setval_295(unsigned *p)
{
    *p = 3373846153U;
}

unsigned getval_422()
{
    return 3286272328U;
}

void setval_347(unsigned *p)
{
    *p = 3674260105U;
}

void setval_271(unsigned *p)
{
    *p = 3531918985U;
}

unsigned getval_321()
{
    return 2425541001U;
}

unsigned getval_291()
{
    return 2425409945U;
}

unsigned addval_384(unsigned x)
{
    return x + 3229929113U;
}

unsigned addval_225(unsigned x)
{
    return x + 2210648457U;
}

unsigned addval_272(unsigned x)
{
    return x + 3375940233U;
}

unsigned addval_264(unsigned x)
{
    return x + 3375944072U;
}

unsigned addval_448(unsigned x)
{
    return x + 3375415945U;
}

unsigned getval_380()
{
    return 3526939016U;
}

unsigned addval_389(unsigned x)
{
    return x + 3682124425U;
}

void setval_461(unsigned *p)
{
    *p = 3269495112U;
}

void setval_177(unsigned *p)
{
    *p = 3372794504U;
}

void setval_474(unsigned *p)
{
    *p = 3675836041U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
