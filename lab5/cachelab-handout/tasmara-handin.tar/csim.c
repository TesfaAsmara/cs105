// Cade Kritsch (loginID ckritsch) and Tesfa Asmara (loginID tasmara)

#include "cachelab.h"
#include <stdio.h>


int hit_count;

int miss_count;

int eviction_count;

int main(int argc, char** argv) {
    printf("%d", argc);
    printf("\n");
    printf("Printing the first argument");
    printf("\n");
    printf(argv[0]);
    printf("\n");
    printf("\n");
    printf(argv[1]);
    printf("\n");
    printf("\n");
    printf(argv[2]);
    printf("\n");
    printf("\n");
    printf(argv[3]);
    printf("\n");

    printSummary(hit_count, miss_count, eviction_count);

    return 0;

}


